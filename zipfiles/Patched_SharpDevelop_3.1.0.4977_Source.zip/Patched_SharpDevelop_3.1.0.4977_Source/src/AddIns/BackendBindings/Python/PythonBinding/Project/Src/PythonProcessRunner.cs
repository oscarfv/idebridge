﻿// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Matthew Ward" email="mrward@users.sourceforge.net"/>
//     <version>$Revision: 2753 $</version>
// </file>

using System;
using ICSharpCode.SharpDevelop.Util;

namespace ICSharpCode.PythonBinding
{
	public class PythonProcessRunner : ProcessRunner, IProcessRunner
	{
	}
}
